<div class="row ">
    <div class="col-md-4">
    </div>
    <div class="col-md-4 text-success text-center background rounded">
        <h3>Your membership was successfully submitted! 🎉 </h3>
    </div>
    <div class="col-md-4">
    </div>
</div>
<div class="row text-light ">
    <div class="col-md-4">
    </div>
    <div class="col-md-4">
        <p><?php echo anchor('news/create', 'Try it again!'); ?></p>
    </div>
    <div class="col-md-4">
    </div>
</div>
