<?php
echo 'hello, friend!';
