<div class="row ">
    <div class="col-md-4">
    </div>
    <div class="col-md-4 text-warning text-center">
        <h3>Your membership was successfully submitted! 🎉 </h3>
    </div>
    <div class="col-md-4">
    </div>
</div>
<div class="row text-light ">
    <div class="col-md-4">
    </div>
    <div class="col-md-4 text-center">
        <p><?php echo anchor('sign_up', 'Try it again!'); ?></p>
    </div>
    <div class="col-md-4">
    </div>
</div>
