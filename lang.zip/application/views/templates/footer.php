
<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<!--        <script src="./js/jquery-3.3.1.slim.min.js"></script>-->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>-->
            <div class="row">
                <div class="col-2 ml-5 ">
                        <a class="fab fa-vk" href="//vk.com/share.php?url=https://valid.url&amp;title=text"></a>
                        <a class="fab fa-telegram" href="tg://msg_url?url=https://valid.url&amp;text=text"></a>
                        <a class="fab fa-whatsapp" href="whatsapp://send?text=text%20https://valid.url"></a>
                        <a class="fab fa-facebook" href="//www.facebook.com/sharer/sharer.php?u=https://valid.url&amp;quote=text"></a>
                    <!--<p class="fab fa-viber">        </p>-->
                </div>
            </div>
        </div>      
    </div>
    <script src="./js/bootstrap.min.js"></script>
    <em>&copy; 2020</em>
    </body>
</html>